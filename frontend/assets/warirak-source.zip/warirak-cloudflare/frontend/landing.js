// Keep existing public-monitor bookmarks working after introducing the welcome page.
if(['#monitor','#reports'].includes(location.hash))location.replace('/monitor'+location.hash);
const reduceMotion=matchMedia('(prefers-reduced-motion: reduce)').matches;
if(!reduceMotion&&'IntersectionObserver'in window){
 const observer=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting){entry.target.classList.add('in-view');observer.unobserve(entry.target);}},{threshold:.08});
 document.querySelectorAll('.about-section,.experience-section,.how-section,.entry-banner').forEach(section=>{section.classList.add('reveal');observer.observe(section);});
}
