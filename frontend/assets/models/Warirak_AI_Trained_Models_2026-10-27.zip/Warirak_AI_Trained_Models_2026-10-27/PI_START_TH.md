# เริ่มใช้โมเดลกับ Raspberry Pi

ใช้ Raspberry Pi OS แบบ 64 บิต ติดตั้งโครงการวารีรักษ์และ dependencies ตามคู่มือทางการ Ultralytics สำหรับ Raspberry Pi: https://docs.ultralytics.com/guides/raspberry-pi/

แตกชุดโมเดลไว้ในโฟลเดอร์ที่คุณเลือก จากโฟลเดอร์ `ai` ของโครงการใช้คำสั่งต่อไปนี้ โดยแก้เส้นทางให้ตรงกับไฟล์ที่แตกไว้:

```sh
python -m warirak_ai.infer --weights /path/to/warirak-yolo26n-public-v2_ncnn_model --thresholds /path/to/confidence-calibration.json --imgsz 800 --source 0 --frames 300 --out runs/boat-detections.jsonl
```

NCNN ที่ให้ส่งออกตามขนาดภาพ 800 พิกเซล ผลความแม่นยำในรายงานใช้ขนาดเดียวกัน ยังไม่มีผล FPS อุณหภูมิ หรือการใช้ไฟที่วัดบน Pi 4 ของคุณ การตรวจพบในภาพไม่นับเป็นการเก็บขยะสำเร็จ

ถ้าต้องการทดลองนโยบายขับ ให้เตรียม observations JSONL จากกล้องและเซนเซอร์ที่สอบเทียบแล้ว และใช้:

```sh
python -m warirak_ai.navigation --policy /path/to/navigation-policy.json --observations /path/to/observations.jsonl
```

โหมดนี้พิมพ์คำสั่งเสนอเท่านั้น ไม่ส่งคำสั่งไป ESP32 หรือมอเตอร์ ตัวอย่างข้อมูลเข้ามี timestamp_unix_ms, battery_percent, clearance_m สามทิศ, armed, manual_override, target_visible และเมื่อเห็นเป้าหมายต้องมี target_bearing_rad กับ target_distance_m ที่ได้จากการสอบเทียบ หากข้อมูลขาดหรือเก่า ระบบเสนอให้หยุด

ประเมินซ้ำด้วยชุดข้อมูลที่แตกไว้ โดยใช้ขนาดภาพและเกณฑ์ความเชื่อมั่นเดียวกับรายงาน:

```sh
python -m warirak_ai.dataset validate --data /path/to/dataset
python -m warirak_ai.evaluate --data /path/to/dataset --weights /path/to/warirak-yolo26n-public-v2_ncnn_model --thresholds /path/to/confidence-calibration.json --imgsz 800 --device cpu --out runs/reproduced-evaluation.json
```

คำสั่งประเมินใช้ภาพสี่เหลี่ยมจัตุรัสแบบ rect=False ตรงกับ NCNN ที่ส่งออกไว้ หากเปลี่ยนกล้องหรือสภาพแวดล้อม ควรสร้างชุดทดสอบของเรือจริงก่อนใช้ผลเพื่อนำเสนอประสิทธิภาพภาคสนาม
